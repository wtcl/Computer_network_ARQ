from flask import Flask, request,render_template,session,make_response
import requests,time,crcmod,random,json

crc32_func = crcmod.mkCrcFun(0x104C11DB7, initCrc=0, xorOut=0xFFFFFFFF)
global window,filecontent,site
window, filecontent, site = [None] * 8, [], [0, 7]

app=Flask(__name__)

def get_frame_seqnum(frame):  # 获取帧对应的序列号
    num = frame[8:10]
    num = int.from_bytes(num, 'little', signed=False)
    return num

def get_frame_data(frame):    # 获取帧中的内容
    data = frame[24:-4]
    return data

def detect_frame(frame):      # 进行校验
    CRC = frame[-4:]
    data = frame[:-4]
    CRC_detect = crc32_func(data).to_bytes(4, 'little', signed=False)
    if CRC == CRC_detect:   # 正确返回TRUE
        return True
    else:                   # 错误返回False
        return False

def content_return(content):   # 返回ack
    try:
        print('return',get_frame_seqnum(content))
        requests.post('http://127.0.0.1:8080/receive',data=(content))
    except Exception as e:
        print(e)
    return

def recover_file(con):   # 向上层传送数据
    with open('recv_file.txt','wb+') as f:
        f.write(con)

def refresh_window(w):
    with open('./static/data/window.json', 'rb') as f:
        content = f.read()
    content = json.loads(content)
    content_list = content["recvwindow"]
    for i in range(8):
        if w[i]==None:
            content_list[i]["status"]="empty"
        else:
            content_list[i]["status"]="full"
    content["sendwindow"] = content_list
    content = json.dumps(content)
    with open('./static/data/window.json', 'w') as f:
        f.write(content)


def store_status(frame,fromw,status):
    with open('./static/data/send.json', 'rb') as f:
        content = f.read()
    content = json.loads(content)
    content_list = content[fromw]
    content_list.append(
        {'id': get_frame_seqnum(frame), 'time': time.strftime("%Y-%m-%d %H:%M:%S"),
         'state': status})
    content[fromw] = content_list
    content = json.dumps(content)
    with open('./static/data/send.json', 'w') as f:
        f.write(content)

def frame_in(a,b,c):   # 判断帧是否在接收窗口中
    if a<=c:
        if a<=b<=c:
            return 1
        else:
            return 0
    else:
        if a<=b:
            return 1
        else:
            if b<=c:
                return 1
            else:
                return 0

def frame_site(a,b):    # 计算新的帧应该在什么位置
    if a<=b:
        return b-a
    else:
        return 16-a+b

@app.route('/')
def hello():
    return 'Hello,请访问8080端口！'

@app.route('/receive',methods={'POST',"GET"})
def receive():
    if request.method == 'POST':
        data=request.get_data()
        print(data)
        time.sleep(random.randint(1,5))
        print(get_frame_seqnum(data))
        if detect_frame(data)==True and random.randint(0,10):  # 传输过程中未损坏
            if frame_in(site[0] , int(get_frame_seqnum(data)) , site[1]):  # 发送的序号可以加入窗口中
                print(2)
                window[frame_site(site[0], get_frame_seqnum(data))] = data
                content_return(data)
                refresh_window(window)
                print('addwindow:', window)
                while 1:
                    if window[0] != None:
                        filecontent.append(get_frame_data(window[0]))
                        window.pop(0)
                        window.append(None)
                        site[0] = (site[0] + 1) % 16
                        site[1] = (site[1] + 1) % 16
                        refresh_window(window)
                    else:
                        break
                print('file:', filecontent)
                recover_file(b''.join(filecontent))
            else:
                store_status(data,'recv','processed')
        else:
            store_status(data, 'recv', 'checknum-error')


if __name__=='__main__':
    with open('recv_file.txt','wb') as f:
        f.write(b'')
    app.run(host='127.0.0.1', port=80, debug=True,threaded=True)