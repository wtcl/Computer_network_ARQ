from flask import Flask, request,render_template
import requests,json,time,copy,crcmod
from concurrent.futures import ThreadPoolExecutor
from apscheduler.schedulers.background import BackgroundScheduler
from urllib import parse

crc32_func = crcmod.mkCrcFun(0x104C11DB7, initCrc=0, xorOut=0xFFFFFFFF)

global window
window=[]

executor = ThreadPoolExecutor(1)
app=Flask(__name__)

def initial():
    with open('./static/data/send.json', 'w') as f:   # 初始化发送信息
        f.write(json.dumps({"send":[],"recv":[]}))

def get_data(filename):  # 获取上层数据，作为传输的数据
    with open(filename, "rb") as f:
        data = f.read()
    datalist=[]
    for i in range(len(data)//1500+1):
        datalist.append(makeFrame(data[:1500],i%16))
        data=data[1500:]
    return datalist

def makeFrame(data, seq_num): # 用于帧的封装
    """:param data: 传入合适大小的数据,长度由函数外进行确定
       :param seq_num: 该帧对应的序列号"""
    prefix = b'\x55' * 7
    SFD = b'\xab'
    # SFD为前导符，用来进行同步，实质上可以认为是用来提醒接收方准备接受一个新的帧
    src = b'sender'
    dst = b'recver'
    if len(data)<46:
        data=data.zfill(46)
    frame_len = (28 + len(data)).to_bytes(2, 'little', signed=False)  # 后续拼接之后进行设置
    # 28 = 7(prefix) + 1(SFD) + 6(src) + 6(dst) + 2(seq_num) + 2(frame_len) + 4(CRC)
    t = prefix + SFD + seq_num.to_bytes(2, 'little', signed=False) + src + dst + frame_len + data
    CRC = crc32_func(t)
    CRC = CRC.to_bytes(4, 'little', signed=False)
    return t + CRC


def get_frame_seqnum(frame):  # 获取帧对应的序列号
    num = frame[8:10]
    num = int.from_bytes(num, 'little', signed=False)
    return num

def get_distence(a,b):    # 获取两个标号间的距离
    if a<=b:
        return b-a
    else:
        return 16-a+b

def refresh_window(w):
    with open('./static/data/window.json', 'rb') as f:
        content = f.read()
    content = json.loads(content)
    content_list = content["sendwindow"]
    s=[get_distence(w[0],w[i]) for i in range(len(w))]
    for i in range(8):
        if i in s:
            content_list[i]["status"]="full"
        else:
            content_list[i]["status"]="empty"
    content["sendwindow"]=content_list
    content = json.dumps(content)
    with open('./static/data/window.json', 'w') as f:
        f.write(content)


def send_again(frame):   # 重发函数
    try:
        requests.post('http://127.0.0.1:80/receive', data=frame, timeout=0.5)
    except:
        print('resend: ', get_frame_seqnum(frame))
        store_status(frame,'send','resended')
        store_status(frame,'recv','lost')

def store_status(frame,fromw,status):
    with open('./static/data/send.json', 'rb') as f:
        content = f.read()
    content = json.loads(content)
    content_list = content[fromw]
    content_list.append(
        {"id": get_frame_seqnum(frame), "time": time.strftime("%Y-%m-%d %H:%M:%S"),
         "state": status})
    content[fromw] = content_list
    content = json.dumps(content)
    with open('./static/data/send.json', 'w') as f:
        f.write(content)

def send_main(filename):         # 主要发送函数
    print(job.get_jobs())
    job.remove_job('main')
    print('success',job.get_jobs())
    datas = get_data(filename)
    print(len(datas))
    example_data = copy.deepcopy(datas)
    for i in range(len(datas)):
        w = 1
        print(window)
        while w:
            try:
                if len(window) == 0 or len(example_data) == 0 or (get_distence(window[0], window[-1]) < 7 and get_distence(window[0], get_frame_seqnum(datas[i])) < 8):
                    # 上面这行会出现一个和运行时间以及全局变量变化时间的问题，于是我在外面又套了个try，为了防止当前面len(window)！=0而后面第三个判断的时候window为空.
                    print(window)
                    try:
                        requests.post('http://127.0.0.1:80/receive', data=datas[i], timeout=0.5)
                    except:
                        job.add_job(send_again, 'interval', seconds=15, id=str(get_frame_seqnum(datas[i])),
                                    args=[datas[i]])
                        # 设置15秒是为了更好的观察整体的动态过程，细节化
                        print(job.get_jobs())
                        print('send: ', get_frame_seqnum(datas[i]))
                        w = 0
                        window.append(get_frame_seqnum(datas[i]))
                        refresh_window(window)
                        example_data.pop(0)
                        print('add: ', window)
                        store_status(datas[i],'send','sended')
            except:
                time.sleep(1)

@app.route('/',methods=['GET','POST'])
def index():
    if request.method=='GET':
        return render_template('start.html')
    else:
        name=request.get_data().decode('utf-8')
        name=parse.unquote(name)
        print(name)
        initial()
        job.add_job(send_main, 'interval', seconds=5, id='main',args=[name[5:]])
        return render_template('send.html')

@app.route('/receive',methods={'POST',"GET"})
def receive():
    if request.method == 'POST':
        datan=request.get_data()
        print('receive: ',datan)
        job.remove_job(str(get_frame_seqnum(datan)))
        window.remove(get_frame_seqnum(datan))
        refresh_window(window)
        print('remove: ',window)
        store_status(datan, 'recv', 'received')
        return 'True'
    else:
        print("Error")

if __name__=='__main__':
    job = BackgroundScheduler(timezone='utc')
    job.start()
    initial()
    app.run(host='127.0.0.1',port=8080,debug=True,threaded=True)
