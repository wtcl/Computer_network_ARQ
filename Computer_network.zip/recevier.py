import random
from flask import Flask, request,render_template,session,make_response
import requests,json,time
from flask_socketio import SocketIO

global window,filecontent,site
window, filecontent, site = [None] * 8, [], [0, 7]

app=Flask(__name__)
socketio = SocketIO(app)

def ttt(content):
    try:
        print('return',content)
        requests.post('http://127.0.0.1:8080/receive',data=json.dumps(content))
    except Exception as e:
        print(e)
    return

@app.route('/')
def hello():
    return 'hello'

@app.route('/receive',methods={'POST',"GET"})
def receive():
    print()
    if request.method == 'POST':
        data=json.loads(request.get_data())
        print(data)
        time.sleep(random.randint(1,5))
        print(1)
        if site[0] <= int(data['id']) <= site[1]:
            print(2)
            window[(int(data['id']) - site[0])]=data
            ttt(data)
            print('addwindow:',window)
            while 1:
                if window[0] != None:
                    filecontent.append(window[0])
                    window.pop(0)
                    window.append(None)
                    site[0] += 1
                    site[1] += 1
                else:
                    break
            print('file:',filecontent)
        else:
            print(data, 'is lost!')

if __name__=='__main__':
    app.run(host='127.0.0.1', port=80, debug=True,threaded=True)