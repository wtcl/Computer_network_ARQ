from flask import Flask, request,render_template
import requests,json,time,copy,datetime
from concurrent.futures import ThreadPoolExecutor
from apscheduler.schedulers.background import BackgroundScheduler

global window
window=[]

executor = ThreadPoolExecutor(1)
app=Flask(__name__)

def package(to_pack_data):
    to_pack_data='EEEEEE'+'000000'+'08'+to_pack_data+'0001'
    return to_pack_data

def send_again(content):
    try:
        requests.post('http://127.0.0.1:80/receive', data=json.dumps(content), timeout=0.5)
    except:
        print('resend: ', content['id'])

@app.route('/',methods=['GET','POST'])
def index():
    return render_template('start.html')

@app.route('/index',methods=['GET',"POST"])
def send():
    return render_template('send.html')

@app.route('/send',methods=['GET','POST'])
def click_begin():
    datas = [i for i in range(2 ** 4)]
    example_data = copy.deepcopy(datas)
    for i in range(len(datas)):
        w = 1
        print(window)
        while w:
            try:
                if len(window) == 0 or len(example_data) == 0 or (
                        (int(window[-1]['id']) - int(window[0]['id'])) < 7 and (i - int(window[0]['id'])) < 8):
                    # 上面这行会出现一个和运行时间以及全局变量变化时间的问题，于是我在外面又套了个try，为了防止当前面len(window)！=0而后面第三个判断的时候window为空.
                    print(window)
                    try:
                        requests.post('http://127.0.0.1:80/receive',
                                      data=json.dumps({'id': str(i), 'data': datas[i]}),
                                      timeout=0.5)
                    except:
                        job.add_job(send_again, 'interval', seconds=15, id=str(datas[i]),
                                    args=[{'id': str(i), 'data': datas[i]}])
                        print(job.get_jobs())
                        print('send: ', datas[i])
                        w = 0
                        window.append({'id': str(i), 'data': datas[i]})
                        example_data.pop(0)
                        print('add: ', window)

                        with open('./static/data/send.json', 'rb') as f:
                            content = f.read()
                        content = json.loads(content)
                        print('content_send:', content)
                        content_list = content['send']
                        content_list.append({'id': str(i), 'time': time.strftime("%Y-%m-%d %H:%M:%S"),'state': 'sended'})
                        content["send"] = content_list
                        content = json.dumps(content)
                        with open('./static/data/send.json', 'w') as f:
                            f.write(content)
            except:
                time.sleep(1)
    return 'Sending over!'


@app.route('/receive',methods={'POST',"GET"})
def receive():
    if request.method == 'POST':
        datan=json.loads(request.get_data())
        print('receive: ',datan['data'])
        job.remove_job(str(datan['data']))
        window.remove(datan)
        print('remove: ',window)

        with open('./static/data/send.json', 'rb') as f:
            content=f.read()
        print('content0:',content)
        content=json.loads(content)
        print('content:', content)
        content_list=content['send']
        content_list.append({'id': datan['id'], 'time':time.strftime("%Y-%m-%d %H:%M:%S"),'state':'received'})
        content["send"]=content_list
        content=json.dumps(content)
        with open('./static/data/send.json', 'w') as f:
            f.write(content)
        return 'True'
    else:
        print("Error")

if __name__=='__main__':
    job = BackgroundScheduler(timezone='utc')
    job.start()
    with open('./static/data/send.json', 'w') as f:
        f.write(json.dumps({"send":[]}))
    app.run(host='127.0.0.1',port=8080,debug=True,threaded=True)
